create trigger UPDATE_JOB_HISTORY
    after update of JOB_ID,DEPARTMENT_ID
    on EMPLOYEES
    for each row
BEGIN
  add_job_history(:old.employee_id, :old.hire_date, sysdate,
                  :old.job_id, :old.department_id);
END;
/

